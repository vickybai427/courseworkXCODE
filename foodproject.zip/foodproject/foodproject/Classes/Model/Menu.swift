//
//  Menu.swift
//  foodproject
//
//  Created by administrator on 2020/10/27.
//

import Foundation

class Menu {
    
    var name: String = ""
    
    var desc: String = ""
    
    var image: String = ""
    
    var isLike: Bool = false
    
    var likeCount: Int = 0
    
    var calories: String = ""
    
    static func defaultMenu() -> [Menu] {

        let dairy = Menu()
        dairy.name = "Dairy"
        dairy.desc = "Dairy and fortified soy products are a vital source of calcium. The USDA recommend consuming low-fat versions whenever possible. Low-fat dairy and soy products include: ricotta or cottage cheese, low-fat milk, yogurt, soy milk. "
        dairy.image = "Dairy.jpg"
        dairy.isLike = false
        dairy.likeCount = 888
        dairy.calories = "Medium"
        
        let fruits = Menu()
        fruits.name = "Fruits"
        fruits.desc = "A balanced diet also includes plenty of fruit. Instead of getting fruit from juice, nutrition experts recommend eating whole fruits. Juice contains fewer nutrients. Also, the manufacturing process often adds empty calories due to added sugar. People should opt for fresh or frozen fruits, or fruits canned in water instead of syrup."
        fruits.image = "Fruits.jpg"
        fruits.isLike = true
        fruits.likeCount = 1222
        fruits.calories = "Low"
        
        let grains = Menu()
        grains.name = "Grains"
        grains.desc = "Whole grains usually contain more protein than refined grains. There are two subgroups: whole grains and refined grains. Whole grains include all three parts of the grain, which are the bran, germ, and endosperm. Refined grains are processed and do not contain the three original components. Refined grains also tend to have less protein and fiber, and they can cause blood sugar spikes. Healthful whole grains include: quinoa, oats, brown rice, barley, buckwheat."
        grains.image = "Grains.jpg"
        grains.isLike = true
        grains.likeCount = 9999
        grains.calories = "Medium"
        
        let protein = Menu()
        protein.name = "Protein"
        protein.desc = "The guidelines suggest that this protein should make up a quarter of a person’s plate. Nutritious protein choices include: lean beef and pork, chicken and turkey, fish, beans, peas, and legumes."
        protein.image = "Protein.jpg"
        protein.isLike = false
        protein.likeCount = 2323
        protein.calories = "High"
        
        let vegetables = Menu()
        vegetables.name = "Vegetables"
        vegetables.desc = "The vegetable group includes five subgroups: leafy greens, red or orange vegetables, starchy vegetables, beans and peas, other vegetables, such as eggplant or zucchini. People may enjoy vegetables raw or cooked. However, it is important to remember that cooking vegetables removes some of their nutritional value. Also, some methods, such as deep-frying, can add unhealthful fats to a dish."
        vegetables.image = "Vegetables.jpg"
        vegetables.isLike = true
        vegetables.likeCount = 9999
        vegetables.calories = "Low"
        
        return [dairy, fruits, grains, protein, vegetables]
    }
}
