//
//  Photo.swift
//  foodproject
//
//  Created by administrator on 2020/12/16.
//

import Foundation
/// Use Codable Protocol to convert Data to Model

struct PhotoURL: Codable {
    var original: String
    var large2x: String
    var medium: String
    var large: String
    var small: String
    var portrait: String
    var landscape: String
    var tiny: String
}

struct PhotoItem: Codable  {
    var url: String
    var photographer: String
    var photographer_url: String
    var id: Int
    var src: PhotoURL
}


struct PhotoResult: Codable  {
    var total_results: Int
    var page: Int
    var per_page: Int
    var photos: [PhotoItem]
}
