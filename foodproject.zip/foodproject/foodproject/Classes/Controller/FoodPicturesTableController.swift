//
//  FoodPicturesTableController.swift
//  foodproject
//
//  Created by administrator on 2020/12/16.
//

import UIKit

class FoodPicturesTableController: UITableViewController {

    /// Table View DataSource
    fileprivate var dataSource: [PhotoItem] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = .none
        tableView.register(UINib(nibName: "FoodPictureTableViewCell", bundle: nil), forCellReuseIdentifier: "FoodPictureTableViewCell")
        tableView.tableFooterView = UIView()
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 176
        
        searchFoodPicture()
    }
    
    /// Search Food Picture
    private func searchFoodPicture() {
        guard let url = URL(string: "https://api.pexels.com/v1/search?query=Food&per_page=50&page=1") else {
            return
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 120
        /// Set Authorization key
        request.addValue("563492ad6f91700001000001bba358cd801f4c4087a13abed47fab5f", forHTTPHeaderField: "Authorization")
        URLSession.shared.dataTask(with: request) {[weak self] (data, response, error) in
            guard let s_self = self else {
                return
            }
            if let error = error {
                // request error
                debugPrint(error.localizedDescription)
            } else {
                guard let data = data else {
                    // no data
                    return
                }
                do {
                    // request success
                    let dataSource = try JSONDecoder().decode(PhotoResult.self, from: data)
                    s_self.dataSource = dataSource.photos
                } catch  {
                    debugPrint(error.localizedDescription)
                }
                DispatchQueue.main.async {
                    s_self.tableView.reloadData()
                }
            }
        }.resume()
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FoodPictureTableViewCell", for: indexPath) as! FoodPictureTableViewCell
        let item = dataSource[indexPath.row]
        cell.photoItem = item
        return cell
    }
    
    /// Animation show UITableViewCell
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.transform = CGAffineTransform(scaleX: 0.7, y: 0.7)
        UIView.animate(withDuration: 0.35, delay: 0, options: UIView.AnimationOptions.curveEaseInOut) {
            cell.transform = .identity
        } completion: { (flag) in
            
        }
    }
    
    /// Selected UITableViewCell Action, goto Detail Page
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showPictureDetail", sender: dataSource[indexPath.row])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier?.elementsEqual("showPictureDetail") ?? false {
            guard let controller = segue.destination as? PictureDetailViewController, let item = sender as? PhotoItem else {
                return
            }
            controller.photoItem = item
        }
    }
}
