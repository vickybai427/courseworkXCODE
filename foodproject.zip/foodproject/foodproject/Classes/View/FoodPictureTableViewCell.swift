//
//  FoodPictureTableViewCell.swift
//  foodproject
//
//  Created by administrator on 2020/12/16.
//

import UIKit

/// Custom UITableViewCell 
class FoodPictureTableViewCell: UITableViewCell {

    @IBOutlet weak var foodPictureImageV: UIImageView!
    @IBOutlet weak var authorL: UILabel!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        authorL.text = nil
        foodPictureImageV.image = nil
    }
    
    public var photoItem: PhotoItem? {
        didSet {
            guard let item = photoItem else {
                authorL.text = nil
                foodPictureImageV.image = nil
                return
            }
            authorL.text = item.photographer
            loadNetworkImage(item: item)
        }
    }
    
    /// Load Picure from network
    private func loadNetworkImage(item: PhotoItem) {
        
        if let imageData = UserDefaults.standard.data(forKey: "\(item.id)") {
            foodPictureImageV.image = UIImage(data: imageData)
            return
        }
        
        var urlString = item.src.medium
        if urlString.count == 0 {
            urlString = item.src.small
        }
        
        guard let url = URL(string: urlString) else {
            return
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 30
        /// Set Authorization key
        request.addValue("563492ad6f91700001000001bba358cd801f4c4087a13abed47fab5f", forHTTPHeaderField: "Authorization")
        URLSession.shared.dataTask(with: request) {[weak self] (data, response, error) in
            guard let s_self = self else {
                return
            }
            if let error = error {
                // request error
                debugPrint(error.localizedDescription)
            } else {
                guard let data = data else {
                    // no data
                    return
                }
                UserDefaults.standard.setValue(data, forKey: "\(item.id)")
                UserDefaults.standard.synchronize()
                if ((s_self.photoItem?.id ?? -1) == item.id) {
                    DispatchQueue.main.async {
                        s_self.foodPictureImageV.image = UIImage(data: data)
                    }
                }
            }
        }.resume()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
