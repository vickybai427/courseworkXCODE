//
//  DetailViewController.swift
//  foodproject
//
//  Created by administrator on 2020/10/27.
//

import UIKit

class DetailViewController: UIViewController {

    /// All food
    lazy var dataSource: [Menu] = Menu.defaultMenu()
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var likeButton: UIButton!
    @IBOutlet weak var caloriesLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var bottomView: UIStackView!
    
    /// Curren Index
    public var index: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateContent()
        becomeFirstResponder()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        /// Hide Navigation Bar
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        resignFirstResponder()
    }

    /// Update Content
    func updateContent() {
        if dataSource.count == 0 {
            return
        }
        if index < 0 || index >= dataSource.count {
            index = 0
        }
        
        let menu = dataSource[index]
        
        titleLabel.text = menu.name
        nameLabel.text = menu.name
        imageView.image = UIImage(named: menu.image)
        caloriesLabel.text = "Calories: \t\(menu.calories)"
        descLabel.text = menu.desc
        likeButton.isSelected = menu.isLike
        likeButton.setTitle("  \(menu.likeCount)", for: .normal)
        likeButton.setTitle("  \(menu.likeCount)", for: .selected)
        
        /// Animate Show
        imageView.transform = CGAffineTransform(scaleX: 0.3, y: 0.3)        /// Image View Scale
        bottomView.transform = CGAffineTransform(translationX: 0, y: 100) // Bottom buttons translation
        imageView.alpha = 0.3 // Alpha
        titleLabel.alpha = 0.3 // Alpha
        nameLabel.alpha = 0.3 // Alpha
        caloriesLabel.alpha = 0.3 // Alpha
        descLabel.alpha = 0.3// Alpha
        
        view.isUserInteractionEnabled = false // isUserInteractionEnabled is no When animating
        UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions.curveEaseInOut) {
            self.imageView.transform = CGAffineTransform.identity  // scale from 0.3 to 1.0
            self.bottomView.transform = CGAffineTransform.identity // translation y from 100 to 0
            self.imageView.alpha = 1.0 // alpha from 0.3 to 1.0
            self.imageView.alpha = 1.0 // alpha from 0.3 to 1.0
            self.titleLabel.alpha = 1.0 // alpha from 0.3 to 1.0
            self.nameLabel.alpha = 1.0 // alpha from 0.3 to 1.0
            self.caloriesLabel.alpha = 1.0 // alpha from 0.3 to 1.0
            self.descLabel.alpha = 1.0// alpha from 0.3 to 1.0
        } completion: { (flag) in
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func backAction(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func likeAction(_ sender: UIButton) {
        if dataSource.count == 0 {
            return
        }
        if index < 0 || index >= dataSource.count {
            index = 0
        }
        let menu = dataSource[index]
        
        /// Update likeCount and isLike
        if menu.isLike {
            menu.isLike = false
            menu.likeCount -= 1
        } else {
            menu.isLike = true
            menu.likeCount += 1
        }
        /// Update Like Button content
        likeButton.isSelected = menu.isLike
        likeButton.setTitle("  \(menu.likeCount)", for: .normal)
        likeButton.setTitle("  \(menu.likeCount)", for: .selected)
    }
    
    @IBAction func nextAction(_ sender: UIButton) {
        randomShow()
    }
    
    /// Random Show Next Food
    func randomShow() {
        /// Randomly generate a number that is different from the current index
        var next_index = Int.random(in: 0..<dataSource.count)
        while dataSource.count > 1 {
            if next_index != index {
                break
            }
            next_index = Int.random(in: 0..<dataSource.count)
        }
        index = next_index
        updateContent()
    }
    
    @IBAction func openWebsiteAction(_ sender: UIButton) {
        guard let url = URL(string: "https://www.cookinglight.com/healthy-living/weight-loss/31-day-healthy-meal-plans") else { return }
        
        /// Open website in safari
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    /// motion
    override var canBecomeFirstResponder: Bool {
        return true
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake {
            randomShow()
        }
    }
}
