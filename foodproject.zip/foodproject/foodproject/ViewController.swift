//
//  MenuListViewController.swift
//  foodproject
//
//  Created by administrator on 10/26/20.
//

import UIKit
import AVKit

class MenuListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    /// All food
    lazy var dataSource: [Menu] = Menu.defaultMenu()

    @IBOutlet weak var soundSwitch: UISwitch!
    
    /// lazy load sound player
    lazy var player: AVAudioPlayer? = {
        guard let url = Bundle.main.url(forResource: "piano", withExtension: "mp3") else {
            return nil
        }
        let object = try? AVAudioPlayer(contentsOf: url)
        object?.numberOfLoops = -1 //loop indefinitely
        object?.volume = 0.5 // set volume
        object?.prepareToPlay()
        return object
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // The audio is off by default
        playSoundIfShould()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        /// Show Navigation Bar
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    fileprivate func playSoundIfShould() {
        if UserDefaults.standard.bool(forKey: "kSoundOpen") {
            player?.play()
            soundSwitch.isOn = true
        } else {
            player?.pause()
            soundSwitch.isOn = false
        }
    }

    @IBAction func soundAction(_ sender: UISwitch) {
        //  Store in UserDefaults
        UserDefaults.standard.setValue(sender.isOn, forKey: "kSoundOpen")
        UserDefaults.standard.synchronize()
        playSoundIfShould();
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UITableViewCell", for: indexPath)
        let menu = dataSource[indexPath.row]
        
        /// Set image
        if let imageView = cell.viewWithTag(1001) as? UIImageView {
            imageView.image = UIImage(named: menu.image)
        }

        /// Set meal name
        if let titleLabel = cell.viewWithTag(1002) as? UILabel {
            titleLabel.text = menu.name
        }
        return cell
    }
    
    /// Did Select UITableView Row, and goto detail page
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        /// perform segue with identifier which configed in Main.storyboard
        performSegue(withIdentifier: "showDetailMeal", sender: indexPath.row)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        /// get sender Index
        if segue.identifier?.elementsEqual("showDetailMeal") ?? false {
            guard let controller = segue.destination as? DetailViewController else { return }
            guard let index = sender as? Int else { return }
            if index >= 0 && index < dataSource.count {
                controller.index = index
            }
        }
        
    }
}

